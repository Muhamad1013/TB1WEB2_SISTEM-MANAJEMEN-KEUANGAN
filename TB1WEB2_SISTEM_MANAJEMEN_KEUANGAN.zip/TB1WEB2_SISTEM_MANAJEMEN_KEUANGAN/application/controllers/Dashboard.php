<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dashboard extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('Keuangan_model');
  }

  public function index()
  {
    $data['pemasukan_hari_ini'] = $this->Keuangan_model->get_pemasukan_hari_ini();
    $data['pengeluaran_hari_ini'] = $this->Keuangan_model->get_pengeluaran_hari_ini();
    $data['pemasukan_bulan_ini'] = $this->Keuangan_model->get_pemasukan_bulan_ini();
    $data['pengeluaran_bulan_ini'] = $this->Keuangan_model->get_pengeluaran_bulan_ini();
    $data['pemasukan_tahun_ini'] = $this->Keuangan_model->get_pemasukan_tahun_ini();
    $data['pengeluaran_tahun_ini'] = $this->Keuangan_model->get_pengeluaran_tahun_ini();

    // Ambil data bulanan untuk grafik
    $bulan = date('m');  // Mendapatkan bulan saat ini (dalam format angka, misalnya "10" untuk Oktober)
    $tahun = date('Y');  // Mendapatkan tahun saat ini (misalnya "2024")

    $data['pemasukan_bulanan'] = $this->Keuangan_model->get_pemasukan_bulanan($bulan, $tahun);
    $data['pengeluaran_bulanan'] = $this->Keuangan_model->get_pengeluaran_bulanan($bulan, $tahun);

    // Load view dengan data
    $this->load->view('dashboard', $data);
  }

  public function get_pemasukan_bulanan()
  {
    $result = [];
    for ($i = 1; $i <= 12; $i++) {
      $this->db->select_sum('nominal_masuk');
      $this->db->where('MONTH(tanggal_masuk)', $i);
      $this->db->where('YEAR(tanggal_masuk)', date('Y'));
      $query = $this->db->get('pemasukan');
      $result[] = $query->row()->nominal_masuk ?: 0;
    }
    return $result;
  }

  public function get_pengeluaran_bulanan()
  {
    $result = [];
    for ($i = 1; $i <= 12; $i++) {
      $this->db->select_sum('nominal_keluar');
      $this->db->where('MONTH(tanggal_keluar)', $i);
      $this->db->where('YEAR(tanggal_keluar)', date('Y'));
      $query = $this->db->get('pengeluaran');
      $result[] = $query->row()->nominal_keluar ?: 0;
    }
    return $result;
  }


}
