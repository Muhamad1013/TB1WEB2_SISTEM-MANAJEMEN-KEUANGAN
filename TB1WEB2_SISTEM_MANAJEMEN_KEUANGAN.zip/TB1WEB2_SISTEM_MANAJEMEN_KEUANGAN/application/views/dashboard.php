<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Keuangan</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Arial', sans-serif;
    }

    .sidebar {
      height: 100vh;
      position: fixed;
      width: 250px;
      background-color: #2c3e50;
      color: white;
      padding-top: 20px;
    }

    .sidebar a {
      color: white;
      display: block;
      padding: 15px;
      text-decoration: none;
    }

    .sidebar a:hover {
      background-color: #34495e;
    }

    .content {
      margin-left: 250px;
      padding: 20px;
    }

    .card {
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
    }

    .card-body h5 {
      font-size: 1.2rem;
      font-weight: bold;
    }

    .icon-info {
      font-size: 1.2rem;
    }

    .more-info {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .card-header {
      font-weight: bold;
    }

    .green-card {
      background-color: #28a745;
      color: white;
    }

    .red-card {
      background-color: #dc3545;
      color: white;
    }

    .blue-card {
      background-color: #007bff;
      color: white;
    }

    .orange-card {
      background-color: #fd7e14;
      color: white;
    }

    .black-card {
      background-color: #343a40;
      color: white;
    }

    .chart-container {
      width: 100%;
      max-width: 650px;
      margin-right: 20px;
      background-color: white;
      border-radius: 15px;
    }

    .calendar-container {
      max-width: auto;
      padding: 10px;
      background-color: lightgray;
      border-radius: 15px;
    }

    .flex-row {
      display: flex;
      margin-top: 20px;
    }

    .chart-container {
      flex: 1;
      max-width: auto;
      margin-right: 20px;
      margin-bottom: 0px;
      background-color: #ffffff;
      padding: 15px;
      border: 1px solid #ddd;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .calendar-container {
      flex: 1;
      max-width: auto;
      background-color: #ffffff;
      padding: 15px;
      border: 1px solid #ddd;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .calendar-container #calendar {
      padding: 10px;
    }
  </style>
</head>

<body>

  <!-- Sidebar -->
  <div class="sidebar">
    <h2 class="text-center">KeuanganApp</h2>
    <p class="text-center">Ahmad Jhony - administrator</p>
    <a href="#">Dashboard</a>
    <a href="#">Data Kategori</a>
    <a href="#">Data Transaksi</a>
    <a href="#">Hutang Piutang</a>
    <a href="#">Rekening Bank</a>
    <a href="#">Data Pengguna</a>
    <a href="#">Laporan</a>
    <a href="#">Ganti Password</a>
    <a href="#">Logout</a>
  </div>

  <div class="content">
    <h2>Dashboard Keuangan</h2>

    <div class="row">
      <div class="col-md-4">
        <div class="card green-card mb-3">
          <div class="card-header">Pemasukan Hari Ini</div>
          <div class="card-body">
            <h5 class="card-title">Rp. <?= $pemasukan_hari_ini ?: 0 ?></h5>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card blue-card mb-3">
          <div class="card-header">Pemasukan Bulan Ini</div>
          <div class="card-body">
            <h5 class="card-title">Rp. <?= $pemasukan_bulan_ini ?: 0 ?></h5>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card text-white bg-warning mb-3">
          <div class="card-header">Pemasukan Tahun Ini</div>
          <div class="card-body">
            <h5 class="card-title">Rp. <?= $pemasukan_tahun_ini ?: 0 ?></h5>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4">
        <div class="card red-card mb-3">
          <div class="card-header">Pengeluaran Hari Ini</div>
          <div class="card-body">
            <h5 class="card-title">Rp. <?= $pengeluaran_hari_ini ?: 0 ?></h5>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card red-card mb-3">
          <div class="card-header">Pengeluaran Bulan Ini</div>
          <div class="card-body">
            <h5 class="card-title">Rp. <?= $pengeluaran_bulan_ini ?: 0 ?></h5>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card text-white bg-danger mb-3">
          <div class="card-header">Pengeluaran Tahun Ini</div>
          <div class="card-body">
            <h5 class="card-title">Rp. <?= $pengeluaran_tahun_ini ?: 0 ?></h5>
          </div>
        </div>
      </div>
    </div>

    <!-- Grafik Data Pemasukan & Pengeluaran Per Bulan -->
    <div class="flex-row">
      <div class="chart-container">
        <h2>Grafik</h2>
        <canvas id="grafikKeuangan" width="300" height="150"></canvas> <!-- Ukuran grafik diubah -->
      </div>
      <div class="calendar-container">
        <h2>Kalender</h2>
        <div id="calendar"></div>
      </div>
    </div>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    var ctx = document.getElementById('grafikKeuangan').getContext('2d');
    var chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
        datasets: [{
          label: 'Pemasukan',
          backgroundColor: 'rgba(75, 192, 192, 0.5)',
          borderColor: 'rgba(75, 192, 192, 1)',
          data: <?= json_encode($pemasukan_bulanan) ?>
        }, {
          label: 'Pengeluaran',
          backgroundColor: 'rgba(255, 99, 132, 0.5)',
          borderColor: 'rgba(255, 99, 132, 1)',
          data: <?= json_encode($pengeluaran_bulanan) ?>
        }]
      },
      options: {
        responsive: true,
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
  </script>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.5.1/main.min.css">
  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.5.1/main.min.js"></script>
  <script>
    document.addEventListener('DOMContentLoaded', function () {
      var calendarEl = document.getElementById('calendar');
      var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        height: 'auto', // Menyesuaikan tinggi kalender
        contentHeight: 'auto' // Menyesuaikan konten tinggi
      });
      calendar.render();
    });
  </script>
</body>

</html>