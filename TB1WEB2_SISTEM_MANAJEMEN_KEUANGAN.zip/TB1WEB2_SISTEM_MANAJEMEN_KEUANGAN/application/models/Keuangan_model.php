<?php
class Keuangan_model extends CI_Model
{

  public function __construct()
  {
    // Panggil constructor dari parent (CI_Model)
    parent::__construct();
    // Load database
    $this->load->database();
  }

  public function get_pemasukan_hari_ini()
  {
    $this->db->select_sum('nominal_masuk');
    $this->db->where('tanggal_masuk', date('Y-m-d'));
    $query = $this->db->get('pemasukan');
    return $query->row()->nominal_masuk;
  }

  public function get_pengeluaran_hari_ini()
  {
    $this->db->select_sum('nominal_keluar');
    $this->db->where('tanggal_keluar', date('Y-m-d'));
    $query = $this->db->get('pengeluaran');
    return $query->row()->nominal_keluar;
  }

  public function get_pemasukan_bulan_ini()
  {
    $this->db->select_sum('nominal_masuk');
    $this->db->where('MONTH(tanggal_masuk)', date('m'));
    $query = $this->db->get('pemasukan');
    return $query->row()->nominal_masuk;
  }

  public function get_pengeluaran_bulan_ini()
  {
    $this->db->select_sum('nominal_keluar');
    $this->db->where('MONTH(tanggal_keluar)', date('m'));
    $query = $this->db->get('pengeluaran');
    return $query->row()->nominal_keluar;
  }

  public function get_pemasukan_bulanan($bulan, $tahun)
  {
    $this->db->select_sum('nominal_masuk');
    $this->db->where('MONTH(tanggal_masuk)', $bulan);
    $this->db->where('YEAR(tanggal_masuk)', $tahun);
    $query = $this->db->get('pemasukan');
    return $query->row()->nominal_masuk;
  }

  // Metode untuk mendapatkan total pengeluaran bulanan
  public function get_pengeluaran_bulanan($bulan, $tahun)
  {
    $this->db->select_sum('nominal_keluar');
    $this->db->where('MONTH(tanggal_keluar)', $bulan);
    $this->db->where('YEAR(tanggal_keluar)', $tahun);
    $query = $this->db->get('pengeluaran'); // Mengambil data dari tabel 'pengeluaran'
    return $query->row()->nominal_keluar;
  }

  public function get_pemasukan_tahun_ini()
  {
    $this->db->select_sum('nominal_masuk');
    $this->db->where('YEAR(tanggal_masuk)', date('Y'));
    $query = $this->db->get('pemasukan');
    return $query->row()->nominal_masuk;
  }

  public function get_pengeluaran_tahun_ini()
  {
    $this->db->select_sum('nominal_keluar');
    $this->db->where('YEAR(tanggal_keluar)', date('Y'));
    $query = $this->db->get('pengeluaran');
    return $query->row()->nominal_keluar;
  }
}
